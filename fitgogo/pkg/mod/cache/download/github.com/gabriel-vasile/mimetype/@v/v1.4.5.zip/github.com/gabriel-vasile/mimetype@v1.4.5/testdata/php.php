#!/usr/bin/env php
<?php echo "php fixture\n";
